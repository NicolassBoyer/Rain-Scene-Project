Nicolas Boyer, 2024
40263939

# Project: rainscene
This is not my project report. Please check the report itself for grading. 
This is just credit for the models and textures I've used in the project.

# code that not written by me:
- stb_image does not belong to me. It is a source file taken from the web in order to implement images in the project.
  It is also present in the lab capsules.
  You can find it in the lab capsules or at https://github.com/nothings/stb/blob/master/stb_image.h

- tinyobjloader is also not mine, and we were given permission to use it as well as part of our project.
   https://github.com/tinyobjloader/tinyobjloader

# Textures used (not mine)
Pavement texture
by Apoorva Joshi
https://www.manytextures.com/texture/58/outdoor-stone-tiles-pavement/

Dirt and wood textures
by Texturer.com
http://texturer.com/set1203/

Brushed Stainless Steel
by textures.com
https://www.textures.com/download/PBR1073/143069

# Models used (also not mine)
Tree, and the bark and leaves textures that come with it
by rezashams313
https://free3d.com/3d-model/tree-74556.html

Street Lamp
by taskirmaz
https://free3d.com/3d-model/street-lamp-419100.html

Low Poly Water Drop
by m53studio
https://sketchfab.com/3d-models/low-poly-water-drop-fb22818ecaa442a1aa8d6b229ece5748

Park\City Bench
by meraj16
https://free3d.com/3d-model/parkcity-bench-505537.html
